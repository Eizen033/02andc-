﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace CollectionsArrayLists
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            ArrayList students = new ArrayList();

            students.Add("Jenny");
            students.Add("Peter");
            students.Add("Mary Jane");

            foreach (string child in students)
            {
                listBox1.Items.Add(child);
            }

            students.Add("Azhar");
            listBox1.Items.Add("new item = " + students[3]);

            listBox1.Items.Add("======================");

            foreach (string child in students)
            {
                listBox1.Items.Add(child);
            }

            students.Sort();
            listBox1.Items.Add("======================");

            foreach (string child in students)
            {
                listBox1.Items.Add(child);
            }

            students.Remove("Peter");
            listBox1.Items.Add("======================");

            foreach (string child in students)
            {
                listBox1.Items.Add(child);
            }

            students.RemoveRange(0, 2);
            listBox1.Items.Add("======================");

            foreach (string child in students)
            {
                listBox1.Items.Add(child);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hashtable students = new Hashtable();
            students.Add("Jenny",87);
            students.Add("Peter","No Score");
            students.Add("Mary Jane",64);
            students.Add("Azhar", 79);

            foreach (DictionaryEntry child in students)
            {
                listBox1.Items.Add("students " + child.Key + ",Score:" + child.Value);
            }
        }
    }
}
