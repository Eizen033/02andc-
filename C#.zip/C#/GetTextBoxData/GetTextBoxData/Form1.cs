﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetTextBoxData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStrings_Click(object sender, EventArgs e)
        {
            string firstName;
            firstName = textBox1.Text;
            MessageBox.Show("Hi," +firstName+ ". How are you?");
        }

        private void btnInteger_Click(object sender, EventArgs e)
        {
            int a;
            a = 25;
            MessageBox.Show(a.ToString());
        }
    }
}
