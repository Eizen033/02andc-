﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AreaCalculation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSquare_Click(object sender, EventArgs e)
        {
            int a;
            a = int.Parse(txt1.Text);
            double result = a * a;
            txt2.Text = result.ToString();
        }

        private void btnCube_Click(object sender, EventArgs e)
        {
            int b;
            b = int.Parse(txt1.Text);
            double result = b * b * b;
            txt2.Text = result.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
