﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello
{
    internal class Hello
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello C#");
        }
    }
}
