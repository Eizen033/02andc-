﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace No4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnUpper_Click(object sender, EventArgs e)
        {
            string ChangeCase = textBox1.Text;
            textBox1.Text = ChangeCase.ToUpper();
        }

        private void btnLower_Click(object sender, EventArgs e)
        {
            string ChangeCase = textBox1.Text;
            textBox1.Text = ChangeCase.ToLower();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 firstform = new Form1();
            firstform.Show();
            this.Hide();
        }
    }
}
