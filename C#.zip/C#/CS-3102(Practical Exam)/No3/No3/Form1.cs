﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace No3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String S1 = "CS3101";
            String S2 = "CS3102";
            String S3 = "CS3103";

            int M1 = int.Parse(textBox1.Text);
            int M2 = int.Parse(textBox2.Text);
            int M3 = int.Parse(textBox3.Text);

            if (M1 < 50 && M2 < 50 && M3 < 50)
            {
                MessageBox.Show("You fail");
            }
            else if (M1 > 50 && M2 > 50 && M3 > 50)
            {
                MessageBox.Show("You Pass");
            }
            else if (M1 >= 80 || M2 >= 80 || M3 >= 80)
            {
                MessageBox.Show("You are distinction!");
                if (M1 >= 80)
                {
                    MessageBox.Show("Your distinction subject is " + S1);
                }
                 if (M2 >= 80)
                {
                    MessageBox.Show("Your distinction subject is " + S2);
                }
                 if (M3 >= 80)
                {
                    MessageBox.Show("Your distinction subject is " + S3);
                }
                else
                {
                    MessageBox.Show("You failed!");
                }
            }
        }
    }
}
