﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DateAndTime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime theDate;
            theDate = DateTime.Now;
            //theDate = DateTime.Today;
            //theDate = DateTime.UtcNow;
            MessageBox.Show(theDate.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(DateTime.Now.ToShortDateString());
            MessageBox.Show(DateTime.Now.ToLongDateString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int d, m, y;
            d = DateTime.Now.Day;
            MessageBox.Show(d.ToString());
            m = DateTime.Now.Month;
            MessageBox.Show(m.ToString());
            y = DateTime.Now.Year;
            MessageBox.Show(y.ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string D = DateTime.Now.DayOfWeek.ToString();
            MessageBox.Show(D.ToString());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Now;
            DateTime answer = today.AddDays(36);
            MessageBox.Show("36 days from today: " + answer);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DateTime date1 = DateTime.Now;
            DateTime date2 = new System.DateTime(2024, 08, 27, 13, 2, 0);
            TimeSpan diff1 = date2.Subtract(date1);
            MessageBox.Show(diff1.Days.ToString());
        }
    }
}
