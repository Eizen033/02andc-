﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckBoxesAndRadioButtons
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSelectM_Click(object sender, EventArgs e)
        {
            string movies = "";
            if (cbComedy.Checked)
            {
                movies = movies + cbComedy.Text + "\r\n";
            }
            if (cbAction.Checked)
            {
                movies = movies + cbAction.Text + "\r\n";
            }
            if (cbSF.Checked)
            {
                movies = movies + cbSF.Text + "\r\n";
            }
            if (cbRomance.Checked)
            {
                movies = movies + cbRomance.Text + "\r\n";
            }
            if (cbAnimation.Checked)
            {
                movies = movies + cbAnimation.Text + "\r\n";
            }
            MessageBox.Show(movies);
        }

        private void btnFavouriteM_Click(object sender, EventArgs e)
        {
            string ChosenMovie = "";
            if (rdComedy.Checked)
            {
                ChosenMovie = rdComedy.Text;
            }
            if (rdAction.Checked)
            {
                ChosenMovie = rdAction.Text;
            }
            if (rdSF.Checked)
            {
                ChosenMovie = rdSF.Text;
            }
            if (rdRomance.Checked)
            {
                ChosenMovie = rdRomance.Text;
            }
            if (rdAnimation.Checked)
            {
                ChosenMovie = rdAnimation.Text;
            }
            MessageBox.Show("Your Favourite type of movie is: " + ChosenMovie);
        }
    }
}
