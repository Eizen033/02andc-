﻿namespace CheckBoxesAndRadioButtons
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbAction = new System.Windows.Forms.CheckBox();
            this.cbSF = new System.Windows.Forms.CheckBox();
            this.cbRomance = new System.Windows.Forms.CheckBox();
            this.cbAnimation = new System.Windows.Forms.CheckBox();
            this.cbComedy = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdComedy = new System.Windows.Forms.RadioButton();
            this.rdAction = new System.Windows.Forms.RadioButton();
            this.rdSF = new System.Windows.Forms.RadioButton();
            this.rdRomance = new System.Windows.Forms.RadioButton();
            this.rdAnimation = new System.Windows.Forms.RadioButton();
            this.btnSelectM = new System.Windows.Forms.Button();
            this.btnFavouriteM = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbAction);
            this.groupBox1.Controls.Add(this.cbSF);
            this.groupBox1.Controls.Add(this.cbRomance);
            this.groupBox1.Controls.Add(this.cbAnimation);
            this.groupBox1.Controls.Add(this.cbComedy);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(23, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(316, 190);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "What Type of Movies Do You Like?";
            // 
            // cbAction
            // 
            this.cbAction.AutoSize = true;
            this.cbAction.Location = new System.Drawing.Point(23, 66);
            this.cbAction.Name = "cbAction";
            this.cbAction.Size = new System.Drawing.Size(79, 24);
            this.cbAction.TabIndex = 4;
            this.cbAction.Text = "Action";
            this.cbAction.UseVisualStyleBackColor = true;
            // 
            // cbSF
            // 
            this.cbSF.AutoSize = true;
            this.cbSF.Location = new System.Drawing.Point(23, 96);
            this.cbSF.Name = "cbSF";
            this.cbSF.Size = new System.Drawing.Size(151, 24);
            this.cbSF.TabIndex = 3;
            this.cbSF.Text = "Science Fiction";
            this.cbSF.UseVisualStyleBackColor = true;
            // 
            // cbRomance
            // 
            this.cbRomance.AutoSize = true;
            this.cbRomance.Location = new System.Drawing.Point(23, 126);
            this.cbRomance.Name = "cbRomance";
            this.cbRomance.Size = new System.Drawing.Size(104, 24);
            this.cbRomance.TabIndex = 2;
            this.cbRomance.Text = "Romance";
            this.cbRomance.UseVisualStyleBackColor = true;
            // 
            // cbAnimation
            // 
            this.cbAnimation.AutoSize = true;
            this.cbAnimation.Location = new System.Drawing.Point(23, 156);
            this.cbAnimation.Name = "cbAnimation";
            this.cbAnimation.Size = new System.Drawing.Size(108, 24);
            this.cbAnimation.TabIndex = 1;
            this.cbAnimation.Text = "Animation";
            this.cbAnimation.UseVisualStyleBackColor = true;
            // 
            // cbComedy
            // 
            this.cbComedy.AutoSize = true;
            this.cbComedy.Location = new System.Drawing.Point(23, 36);
            this.cbComedy.Name = "cbComedy";
            this.cbComedy.Size = new System.Drawing.Size(92, 24);
            this.cbComedy.TabIndex = 0;
            this.cbComedy.Text = "Comedy";
            this.cbComedy.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdAnimation);
            this.groupBox2.Controls.Add(this.rdRomance);
            this.groupBox2.Controls.Add(this.rdSF);
            this.groupBox2.Controls.Add(this.rdAction);
            this.groupBox2.Controls.Add(this.rdComedy);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(371, 32);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(298, 190);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "And Your Favourite Is?";
            // 
            // rdComedy
            // 
            this.rdComedy.AutoSize = true;
            this.rdComedy.Location = new System.Drawing.Point(24, 36);
            this.rdComedy.Name = "rdComedy";
            this.rdComedy.Size = new System.Drawing.Size(91, 24);
            this.rdComedy.TabIndex = 0;
            this.rdComedy.TabStop = true;
            this.rdComedy.Text = "Comedy";
            this.rdComedy.UseVisualStyleBackColor = true;
            // 
            // rdAction
            // 
            this.rdAction.AutoSize = true;
            this.rdAction.Location = new System.Drawing.Point(24, 66);
            this.rdAction.Name = "rdAction";
            this.rdAction.Size = new System.Drawing.Size(78, 24);
            this.rdAction.TabIndex = 1;
            this.rdAction.TabStop = true;
            this.rdAction.Text = "Action";
            this.rdAction.UseVisualStyleBackColor = true;
            // 
            // rdSF
            // 
            this.rdSF.AutoSize = true;
            this.rdSF.Location = new System.Drawing.Point(24, 96);
            this.rdSF.Name = "rdSF";
            this.rdSF.Size = new System.Drawing.Size(150, 24);
            this.rdSF.TabIndex = 2;
            this.rdSF.TabStop = true;
            this.rdSF.Text = "Science Fiction";
            this.rdSF.UseVisualStyleBackColor = true;
            // 
            // rdRomance
            // 
            this.rdRomance.AutoSize = true;
            this.rdRomance.Location = new System.Drawing.Point(24, 126);
            this.rdRomance.Name = "rdRomance";
            this.rdRomance.Size = new System.Drawing.Size(103, 24);
            this.rdRomance.TabIndex = 3;
            this.rdRomance.TabStop = true;
            this.rdRomance.Text = "Romance";
            this.rdRomance.UseVisualStyleBackColor = true;
            // 
            // rdAnimation
            // 
            this.rdAnimation.AutoSize = true;
            this.rdAnimation.Location = new System.Drawing.Point(24, 156);
            this.rdAnimation.Name = "rdAnimation";
            this.rdAnimation.Size = new System.Drawing.Size(107, 24);
            this.rdAnimation.TabIndex = 4;
            this.rdAnimation.TabStop = true;
            this.rdAnimation.Text = "Animation";
            this.rdAnimation.UseVisualStyleBackColor = true;
            // 
            // btnSelectM
            // 
            this.btnSelectM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectM.Location = new System.Drawing.Point(123, 254);
            this.btnSelectM.Name = "btnSelectM";
            this.btnSelectM.Size = new System.Drawing.Size(184, 41);
            this.btnSelectM.TabIndex = 2;
            this.btnSelectM.Text = "Selected Movies";
            this.btnSelectM.UseVisualStyleBackColor = true;
            this.btnSelectM.Click += new System.EventHandler(this.btnSelectM_Click);
            // 
            // btnFavouriteM
            // 
            this.btnFavouriteM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFavouriteM.Location = new System.Drawing.Point(409, 254);
            this.btnFavouriteM.Name = "btnFavouriteM";
            this.btnFavouriteM.Size = new System.Drawing.Size(184, 41);
            this.btnFavouriteM.TabIndex = 3;
            this.btnFavouriteM.Text = "Favourite Movie";
            this.btnFavouriteM.UseVisualStyleBackColor = true;
            this.btnFavouriteM.Click += new System.EventHandler(this.btnFavouriteM_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFavouriteM);
            this.Controls.Add(this.btnSelectM);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbAction;
        private System.Windows.Forms.CheckBox cbSF;
        private System.Windows.Forms.CheckBox cbRomance;
        private System.Windows.Forms.CheckBox cbAnimation;
        private System.Windows.Forms.CheckBox cbComedy;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdAnimation;
        private System.Windows.Forms.RadioButton rdRomance;
        private System.Windows.Forms.RadioButton rdSF;
        private System.Windows.Forms.RadioButton rdAction;
        private System.Windows.Forms.RadioButton rdComedy;
        private System.Windows.Forms.Button btnSelectM;
        private System.Windows.Forms.Button btnFavouriteM;
    }
}

