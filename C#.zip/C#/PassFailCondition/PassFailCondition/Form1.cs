﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PassFailCondition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String Name = txt1.Text;
            String RoleNo = txt2.Text;
            String Class = txt3.Text;

            MessageBox.Show(txt1.Text + ", No." + txt2.Text + ", From " + txt3.Text);
            int S1 = int.Parse(sub1.Text);
            int S2 = int.Parse(sub2.Text);
            int S3 = int.Parse(sub3.Text);
            int S4 = int.Parse(sub4.Text);
            int S5 = int.Parse(sub5.Text);
            String Result = "Myanmar: " + S1 + "\nEnglish: " + S2 + "\nMathematic: " + S3 + "\nScience: " + S4 + "\nBiology: " + S5;
            
            if (S1>=50 &&  S2>=50 && S3>=50 && S4>=50 && S5>=50)
            {
                MessageBox.Show("You Passed", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                MessageBox.Show(Result,"Result", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }else
            {
                MessageBox.Show("You Failed", "Message", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                MessageBox.Show(Result, "Result", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            sub1.Clear();
            sub2.Clear();
            sub3.Clear();
            sub4.Clear();
            sub5.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
