﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoopExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            int loopStart, loopEnd, answer = 0;
            loopStart = int.Parse(txt1.Text);
            loopEnd = int.Parse(txt2.Text);
            for (int i = loopStart; i <= loopEnd; i++)
            {
                answer = answer + i;
                list1.Items.Add("i=" + i + " answer=" + answer.ToString());
            }
        }
    }
}
